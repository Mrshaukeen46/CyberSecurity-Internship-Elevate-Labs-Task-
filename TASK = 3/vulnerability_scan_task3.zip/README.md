# Vulnerability Scan - Task 3

## Objective
Perform a basic vulnerability scan on the local machine using **Nessus Essentials** or **OpenVAS**.

## Tools Used
- Nessus Essentials (free version)
- Localhost / system IP as target

## Steps Followed
1. Installed Nessus Essentials.
2. Configured scan target (local machine IP).
3. Ran a full vulnerability scan.
4. Collected results (vulnerabilities categorized by severity).
5. Documented critical vulnerabilities and researched mitigations.

## Key Results
- Discovered common system vulnerabilities (patch/update related).
- Identified open ports and potential risks.
- Learned about CVSS scoring and remediation prioritization.

## Deliverables
- `report.pdf`: Detailed vulnerability scan summary.
- `screenshots/`: Place scan screenshots here.
- This `README.md` explaining the process.

## How to Use
1. Open `report.pdf` for a summary of findings.
2. Review screenshots folder for actual scan outputs.
3. Refer to this README for methodology.

---

**Note:** This is a sample project prepared for Cyber Security Internship Task 3 submission.
